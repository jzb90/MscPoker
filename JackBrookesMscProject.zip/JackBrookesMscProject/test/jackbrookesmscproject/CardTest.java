/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Jzb3
 */
public class CardTest {
    
    Card testCard1 = new Card(0, 0);
    Card testCard2 = new Card(6, 2);
    
    public void gradeTest() {
        
        assertEquals(this.testCard1.getGrade(), 0L);
        assertEquals(this.testCard2.getGrade(), 6L);
    }
    @Test
    public void suitTest(){
        assertEquals(this.testCard1.getSuit(), 0L);
        assertEquals(this.testCard2.getSuit(), 2L);
    }
    
    @Test
    public void suitStringTest(){
        assertEquals(this.testCard1.getSuitString(), "spades");
        assertEquals(this.testCard2.getSuitString(), "hearts");
    }
    
    @Test
    public void gradeStringTest(){
        assertEquals(this.testCard1.getGradeString(), "ace");
        assertEquals(this.testCard2.getGradeString(), "7");
    }
    
    @Test
    public void toStringTest(){
        assertEquals(this.testCard1.toString(), "ace of spades");
        assertEquals(this.testCard2.toString(), "7 of hearts");
    }
     
}
