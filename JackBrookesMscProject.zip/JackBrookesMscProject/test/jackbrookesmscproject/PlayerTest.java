package jackbrookesmscproject;

import java.util.ArrayList;
import org.junit.Assert;
import org.junit.Test;

public class PlayerTest
{
  @Test
  public void playerCreation()
  {
    Pot pot = new Pot();
    Player player1 = new Player("Player", false, pot, Boolean.valueOf(true));
    Player player2 = new Player("Player", false, pot, Boolean.valueOf(true));
    
    player1.placeBlinds();
    System.out.println(pot.getPotAmount());
    player2.placeBlinds();
    System.out.println(pot.getPotAmount());
  }
  
  @Test
  public void opponentCreation()
  {
      Pot pot = new Pot();
      Table table = new Table();
      Deck deck = new Deck();
      
      Opponent.tightAggressiveOpponent opponent = new Opponent.tightAggressiveOpponent("Jeremy (TA)", true, pot, table);
      ((Player)opponent).dealHand(deck);
       System.out.println(opponent.returnHand().toString());
  }
  
  @Test
  public void testOpponentgetHand()
  {
      Pot pot = new Pot();
      Table table = new Table();
      Deck deck = new Deck();
      Opponent.tightAggressiveOpponent opponent = new Opponent.tightAggressiveOpponent("Jeremy (TA)", true, pot, table);
      ((Player)opponent).dealHand(deck);
      System.out.println(opponent.returnHand().toString());
      
  }
  
  @Test
  public void playStyleTest()
  {
    Pot pot = new Pot();
    Player p = new Player("Player", false, pot, Boolean.valueOf(true));
    p.setOpponentPlayStyle(PlayStyle.LOOSEAGGRESSIVE);
    Assert.assertTrue(p.getOpponentPlayStyle() == PlayStyle.LOOSEAGGRESSIVE);
  }
  
  @Test
  public void foldTest()
  {
    Pot pot = new Pot();
    Table table = new Table();
    Deck deck = new Deck();
    Player player1 = new Player("Player", false, pot, Boolean.valueOf(true));
    Player player2 = new Player("Player", false, pot, Boolean.valueOf(true));
    
    player1.placeBlinds();
    System.out.println(pot.getPotAmount());
    player2.placeBlinds();
    System.out.println(pot.getPotAmount());
    Opponent.tightAggressiveOpponent opponent = new Opponent.tightAggressiveOpponent("Jeremy (TA)", true, pot, table);
    ((Player)opponent).dealHand(deck);
    System.out.println(opponent.returnHand().toString());
    player1.fold(player1, opponent, pot);
  }
  
  @Test
  public void opponentFoldTest()
  {
    Pot pot = new Pot();
    Table table = new Table();
    Deck deck = new Deck();
    Player player1 = new Player("Player", false, pot, Boolean.valueOf(true));
    Opponent.tightAggressiveOpponent opponent = new Opponent.tightAggressiveOpponent("Jeremy (TA)", true, pot, table);
    
    player1.placeBlinds();
    System.out.println(pot.getPotAmount());
    ((Player)opponent).placeBlinds();
    System.out.println(pot.getPotAmount());
    ((Player)opponent).dealHand(deck);
    System.out.println(opponent.returnHand().toString());
    ((Player)opponent).fold(opponent, player1, pot);
  }
  
   @Test
  public void checkTest()
  {
    Pot pot = new Pot();
    Table table = new Table();
    Deck deck = new Deck();
    Player player1 = new Player("Player", false, pot, Boolean.valueOf(true));
    Player player2 = new Player("Player", false, pot, Boolean.valueOf(true));
    
    player1.placeBlinds();
    System.out.println(pot.getPotAmount());
    player2.placeBlinds();
    System.out.println(pot.getPotAmount());
    Opponent.tightAggressiveOpponent opponent = new Opponent.tightAggressiveOpponent("Jeremy (TA)", true, pot, table);
    ((Player)opponent).dealHand(deck);
    System.out.println(opponent.returnHand().toString());
    player1.check(player1, pot);
  }
  
    @Test
  public void opponentCheckTest()
  {
    Pot pot = new Pot();
    Table table = new Table();
    Deck deck = new Deck();
    Player player1 = new Player("Player", false, pot, Boolean.valueOf(true));
    Opponent.tightAggressiveOpponent opponent = new Opponent.tightAggressiveOpponent("Jeremy (TA)", true, pot, table);
    player1.placeBlinds();
    System.out.println(pot.getPotAmount());
    ((Player)opponent).placeBlinds();
    System.out.println(pot.getPotAmount());
    ((Player)opponent).dealHand(deck);
    System.out.println(opponent.returnHand().toString());
    ((Player)opponent).check(opponent, pot);
  }
  
  @Test
  public void raiseTest()
  {
    Pot pot = new Pot();
    Table table = new Table();
    Deck deck = new Deck();
    Player player1 = new Player("Player", false, pot, Boolean.valueOf(true));
    Opponent.tightAggressiveOpponent opponent = new Opponent.tightAggressiveOpponent("Jeremy (TA)", true, pot, table);
    player1.placeBlinds();
    System.out.println(pot.getPotAmount());
    opponent.placeBlinds();
    System.out.println(pot.getPotAmount());
    
    ((Player)opponent).dealHand(deck);
    System.out.println(opponent.returnHand().toString());
    player1.raise(player1, pot, 30);
    System.out.println(player1.getBetTag());
      
  }
  
  @Test
  public void callTest()
  {
      Pot pot = new Pot();
      Table table = new Table();
      Deck deck = new Deck();
      Player player1 = new Player("Player", false, pot, Boolean.valueOf(true));
      Opponent.tightAggressiveOpponent opponent = new Opponent.tightAggressiveOpponent("Jeremy (TA)", true, pot, table);
      player1.placeBlinds();
      System.out.println(pot.getPotAmount());
      opponent.placeBlinds();
      System.out.println(pot.getPotAmount());
      
      ((Player)opponent).dealHand(deck);
      System.out.println(opponent.returnHand().toString());
      opponent.raise(opponent, pot, 30);
      player1.call(player1, opponent);

   }
  
  
}