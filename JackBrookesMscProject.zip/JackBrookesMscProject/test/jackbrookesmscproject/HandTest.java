/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class HandTest {
    
    @Test
    public void orderHandTest() {
        
        Deck testDeck = new Deck();
        Hand testHand = new Hand(testDeck);
        System.out.println(testDeck.toString());
        testHand.orderHand(testHand);
        System.out.println(testHand.toString());
    }
    
    @Test
    public void toStringTest()
    {
        Card card = new Card(0,0);
        assertEquals(card.toString(), "ace of spades");
    }
    
    @Test
    public void clearHandTest()
    {
        Deck testDeck = new Deck();
        Hand testHand = new Hand(testDeck);
        assertFalse(testHand.getDealtCards().size() == 0);
        testHand.clearHand();
        assertTrue(testHand.getDealtCards().size() ==0);
    }
    
    @Test
    public void orderHandTest1()
    {
        Card card5 = new Card (4, 0);
        Card card6 = new Card (5,0);
        Hand hand = new Hand(card6, card5);
        hand.orderHand(hand);
        assertTrue(hand.getDealtCards().get(0) == card5);
        assertTrue(hand.getDealtCards().get(1) == card6);
    }
    
    @Test
    public void testOrderArrayList()
    {
        Card card12 = new Card(10, 1);
        Card card13 = new Card(11, 0);
        Card card17 = new Card(4,2);
        ArrayList<Card> x = new ArrayList();
        x.add(card17);
        x.add(card13);
        x.add(card12);
        Hand.orderArrayList(x);
        assertTrue(x.get(0) == card17);
        assertTrue(x.get(2) == card13);
        System.out.println(x);
    }
    
    @Test
    public void swapArrayCardsTest()
    {
        Card card12 = new Card(10, 1);
        Card card13 = new Card(11, 0);
        Card card17 = new Card(4, 2);
        ArrayList<Card> x = new ArrayList();
        x.add(card17);
        x.add(card13);
        x.add(card12);
        System.out.println(x);
        Hand.swapArrayCards(x, 0, 2);
        assertTrue(x.get(0) == card12);
        System.out.println(x);
    }
    
    @Test
    public void containsRankTest()
    {
        Card card12 = new Card(10, 1);
        Card card13 = new Card(11, 0);
        Card card17 = new Card(4, 2);
        ArrayList<Card> x = new ArrayList();
        x.add(card17);
        x.add(card13);
        x.add(card12);
        assertNotNull(Hand.containsGrade(x, 10));
        assertNull(Hand.containsGrade(x, 3));
    }
    
    @Test
    public void orderByGradeTest()
    {
        Card card12 = new Card(10, 1);
        Card card13 = new Card(11,0);
        Card card17 = new Card(4, 2);
        ArrayList<Card> x = new ArrayList();
        x.add(card17);
        x.add(card13);
        x.add(card12);
        Hand.orderByGrade(x);
        assertTrue(x.get(0) == card17);
        assertTrue(x.get(2) == card13);
    }
    
    @Test
    public void orderByGradeAcesLastTest()
    {
        Card card12 = new Card(10, 1);
        Card card13 = new Card(0,0);
        Card card17 = new Card(4, 2);
        ArrayList<Card> x = new ArrayList();
        x.add(card17);
        x.add(card13);
        x.add(card12);
        Hand.orderByGradeAcesLast(x);
        assertTrue(x.get(0) == card17);
        assertTrue(x.get(2) == card13);
    }
    
    @Test
    public void orderBySuitTest()
    {
        Card card12 = new Card(10, 1);
        Card card13 = new Card(11,0);
        Card card17 = new Card(4, 2);
        ArrayList<Card> x = new ArrayList();
        x.add(card12);
        x.add(card17);
        x.add(card13);
        System.out.println(x);
        Hand.orderBySuit(x);
        assertTrue(x.get(0) == card13);
        assertTrue(x.get(2) == card17);
    }
}
