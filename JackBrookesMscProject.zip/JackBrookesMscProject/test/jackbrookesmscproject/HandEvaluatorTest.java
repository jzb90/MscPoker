/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

import java.util.ArrayList;
import org.junit.Assert;
import org.junit.Test;

public class HandEvaluatorTest
{
  Card card0 = new Card(0, 0);
  Card card1 = new Card(1, 0);
  Card card2 = new Card(1, 1);
  Card card3 = new Card(1, 2);
  Card card4 = new Card(1, 3);
  Card card5 = new Card(4, 0);
  Card card6 = new Card(5, 0);
  Card card7 = new Card(6, 0);
  Card card8 = new Card(7, 0);
  Card card9 = new Card(8, 0);
  Card card10 = new Card(9, 0);
  Card card11 = new Card(10, 0);
  Card card12 = new Card(10, 1);
  Card card13 = new Card(11, 0);
  Card card14 = new Card(12, 0);
  Card card15 = new Card(10, 0);
  Card card16 = new Card(2, 2);
  Card card17 = new Card(4, 2);
  Card cardr1 = new Card(7, 3);
  Card cardr2 = new Card(3, 3);
  Card cardr3 = new Card(5, 2);
  Card cardr4 = new Card(7, 1);
  Card cardr5 = new Card(10, 3);
  Card cardr6 = new Card(9, 2);
  Hand hand = new Hand(this.card8, this.card9);
  Hand hand1 = new Hand(this.card16, this.card17);
  Hand randHand = new Hand(this.card0, this.card10);
  Hand noPairHand = new Hand(this.card5, this.card6);
  Table noPairTable = new Table(this.card7, this.card8, this.card9, this.card10, this.card11);
  Table pairTable = new Table(this.card3, this.card4, this.card5, this.card6, this.card7);
  Table TOAKTable = new Table(this.card2, this.card3, this.card4, this.card5, this.card6);
  Table FOAKTable = new Table(this.card1, this.card2, this.card3, this.card4, this.card5);
  Table straightTable = new Table(this.card5, this.card6, this.card7, this.card13, this.card2);
  Table flushTable = new Table(this.card7, this.card5, this.card3, this.card4, this.card6);
  Table nonStraightFlushTable = new Table(this.card13, this.card6, this.card5, this.card4, this.card3);
  Table nonFlushStraightTable = new Table(this.card17, this.card6, this.card7, this.cardr4, this.cardr6);
  Table straightToAceFlushTable = new Table(this.card10, this.card15, this.card13, this.card14, this.card0);
  Table randomTable = new Table(this.cardr1, this.cardr2, this.cardr3, this.cardr4, this.cardr5);
  HandEvaluator hE = new HandEvaluator();
  Card[] noPairArray = this.hE.concatenateCardsToArray(this.noPairHand, this.noPairTable);
  Card[] pairArray = this.hE.concatenateCardsToArray(this.hand, this.pairTable);
  Card[] TOAKArray = this.hE.concatenateCardsToArray(this.hand, this.TOAKTable);
  Card[] FOAKArray = this.hE.concatenateCardsToArray(this.hand, this.FOAKTable);
  ArrayList<Card> noPairArrayList = this.hE.concatenateCardsToArrayList(this.hand1, this.noPairTable);
  ArrayList<Card> pairArrayList = this.hE.concatenateCardsToArrayList(this.hand1, this.pairTable);
  ArrayList<Card> onePairArrayList = this.hE.concatenateCardsToArrayList(this.randHand, this.randomTable);
  ArrayList<Card> TOAKArrayList = this.hE.concatenateCardsToArrayList(this.hand, this.TOAKTable);
  ArrayList<Card> FOAKArrayList = this.hE.concatenateCardsToArrayList(this.hand, this.FOAKTable);
  ArrayList<Card> flushArrayList = this.hE.concatenateCardsToArrayList(this.hand, this.flushTable);
  ArrayList<Card> nonStaightFlushArrayList = this.hE.concatenateCardsToArrayList(this.hand, this.nonStraightFlushTable);
  ArrayList<Card> nonFlushStraightArrayList = this.hE.concatenateCardsToArrayList(this.hand, this.nonFlushStraightTable);
  ArrayList<Card> staightToAceFlushArrayList = this.hE.concatenateCardsToArrayList(this.hand, this.straightToAceFlushTable);
  
  @Test
  public void evaluateStraightFlushToAce()
  {
    System.out.println(this.staightToAceFlushArrayList);
    System.out.println(this.hE.evaluate(this.staightToAceFlushArrayList));
  }
  
  @Test
  public void evaluateOnePair()
  {
    System.out.println(this.onePairArrayList);
    System.out.println(this.hE.evaluate(this.onePairArrayList));
  }
  
  @Test
  public void evaluateTwoPair()
  {
    System.out.println(this.pairArrayList);
    System.out.println(this.hE.evaluate(this.pairArrayList));
  }
  
  @Test
  public void evaluateTOAK()
  {
    System.out.println(this.TOAKArrayList);
    System.out.println(this.hE.evaluate(this.TOAKArrayList));
  }
  
  @Test
  public void evaluateFOAK()
  {
    System.out.println(this.FOAKArrayList);
    System.out.println(this.hE.evaluate(this.FOAKArrayList));
  }
  
  @Test
  public void evaluateFlush()
  {
    System.out.println(this.nonStaightFlushArrayList);
    System.out.println(this.hE.evaluate(this.nonStaightFlushArrayList));
  }
  
  @Test
  public void evaluateStraight()
  {
    System.out.println(this.nonFlushStraightArrayList);
    for (Card x : this.nonFlushStraightArrayList) {
      System.out.println(x.getGrade());
    }
    System.out.println(Hand.orderByGrade(this.nonFlushStraightArrayList));
    System.out.println(this.hE.straight(this.nonFlushStraightArrayList));
  }
  
  @Test
  public void concatenationToArrayTest()
  {
    Card[] thisArray = this.hE.concatenateCardsToArray(this.hand, this.pairTable);
    Card[] comparison = {
      this.card8, this.card9, this.card3, this.card4, this.card5, this.card6, this.card7 };
    
    Assert.assertArrayEquals(thisArray, comparison);
  }
  
  @Test
  public void concatenationToArrayListTest()
  {
    System.out.println(this.hand);
    System.out.println(this.pairTable.toString());
    ArrayList<Card> thisArray = this.hE.concatenateCardsToArrayList(this.hand, this.pairTable);
    ArrayList<Card> comparison = new ArrayList();
    comparison.add(this.card8);
    comparison.add(this.card9);
    comparison.add(this.card3);
    comparison.add(this.card4);
    comparison.add(this.card5);
    comparison.add(this.card6);
    comparison.add(this.card7);
    Assert.assertEquals(thisArray, comparison);
  }
  
  @Test
  public void pairTest()
  {
    Assert.assertNotNull(this.hE.pair(this.pairArrayList));
  }
  
  @Test
  public void threeOfAKindTest()
  {
    Assert.assertNull(this.hE.threeOfAKind(this.pairArrayList));
    Assert.assertNotNull(this.hE.threeOfAKind(this.TOAKArrayList));
  }
  
  @Test
  public void fourOfAKindTest()
  {
    Assert.assertNotNull(this.hE.fourOfAKind(this.FOAKArrayList));
    Assert.assertNull(this.hE.fourOfAKind(this.TOAKArrayList));
  }
  
  @Test
  public void dynamicNullTest()
  {
    Assert.assertNull(this.hE.twoThreeFourOfAKind(this.noPairArrayList));
  }
  
  @Test
  public void dynamicPairTest()
  {
    System.out.println(this.hE.twoThreeFourOfAKind(this.pairArrayList));
    Assert.assertTrue(this.hE.twoThreeFourOfAKind(this.pairArrayList).size() == 2);
  }
  
  @Test
  public void dynamicTOAKTest()
  {
    System.out.println(this.hE.twoThreeFourOfAKind(this.TOAKArrayList));
    Assert.assertTrue(this.hE.twoThreeFourOfAKind(this.TOAKArrayList).size() == 3);
  }
  
  @Test
  public void dynamicFOAKTest()
  {
    System.out.println(this.hE.twoThreeFourOfAKind(this.FOAKArrayList));
    Assert.assertTrue(this.hE.twoThreeFourOfAKind(this.FOAKArrayList).size() == 4);
  }
  
  @Test
  public void removeThreeOfAKindTest()
  {
    ArrayList<Card> demo = new ArrayList();
    demo.add(this.card8);
    demo.add(this.card9);
    demo.add(this.card5);
    demo.add(this.card6);
    
    Assert.assertEquals(this.hE.removeThreeOfAKind(this.TOAKArrayList), demo);
  }
  
  @Test
  public void fullHouseTest()
  {
    ArrayList<Card> cards = new ArrayList();
    cards.add(this.card1);
    cards.add(this.card2);
    cards.add(this.card3);
    cards.add(this.card9);
    cards.add(this.card10);
    cards.add(this.card11);
    cards.add(this.card12);
    Assert.assertNotNull(this.hE.fullHouse(cards));
  }
  
  @Test
  public void straightTest()
  {
    System.out.println("original");
    System.out.println(this.nonFlushStraightArrayList);
    ArrayList<Card> x = Hand.orderArrayList(this.nonFlushStraightArrayList);
    System.out.println("ordered");
    System.out.println(x);
    System.out.println("method");
    System.out.println(this.hE.straight(x));
    Assert.assertNotNull(this.hE.straight(x));
  }
  
  @Test
  public void flushTest()
  {
    System.out.println("original");
    System.out.println(this.flushArrayList);
    ArrayList<Card> x = Hand.orderArrayList(this.flushArrayList);
    System.out.println("ordered");
    System.out.println(x);
    System.out.println("method");
    System.out.println(this.hE.flush(x));
    Assert.assertNotNull(this.hE.flush(x));
    Assert.assertNotNull(this.hE.flush(this.nonStaightFlushArrayList));
    Assert.assertNull(this.hE.flush(this.FOAKArrayList));
  }
  
  @Test
  public void straightFlushTest()
  {
    System.out.println("original");
    System.out.println(this.flushArrayList);
    ArrayList<Card> x = Hand.orderArrayList(this.flushArrayList);
    System.out.println("ordered");
    System.out.println(x);
    System.out.println("method");
    System.out.println(this.hE.flush(x));
    Assert.assertNotNull(this.hE.straightFlush(x));
    System.out.println(this.hE.straightFlush(this.nonStaightFlushArrayList));
    Assert.assertNull(this.hE.straight(this.nonStaightFlushArrayList));
  }
}