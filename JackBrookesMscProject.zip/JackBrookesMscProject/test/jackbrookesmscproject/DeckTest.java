/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

import java.util.ArrayList;
import org.junit.Assert;
import org.junit.Test;
import java.util.Set;
import java.util.HashSet;

/**
 *
 * @author Admin
 */
public class DeckTest {
    
    Deck sampleDeck = new Deck();
    ArrayList<Card> testDeckOfCards = this.sampleDeck.getDeck();
    Card sampleCard = new Card(2,2);
    
    @Test
    public void deckSizeTest() {
        
        Assert.assertTrue(this. testDeckOfCards.size() == 52);
    }
    
    @Test
    public void individualCard() {
        
        Set<Card> testSet = new HashSet();
        for (Card i : this.testDeckOfCards){
            testSet.add(i);
        }
        Assert.assertTrue(testSet.size() == 52);
    }
    
    @Test
    public void getCardFromTestDeck(){
        Card nullCard = new Card(10, 10);
        Assert.assertNull(this.sampleDeck.getCardFromDeck(nullCard));
    }
    
    @Test
    public void getTopCard(){
        Card card = (Card)this.testDeckOfCards.get(0);
        Assert.assertEquals(this.sampleDeck.drawTopCard(), card);
    }
    
   
    
}
