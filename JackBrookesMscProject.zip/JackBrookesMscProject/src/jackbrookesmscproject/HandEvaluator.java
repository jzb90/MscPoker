
package jackbrookesmscproject;

import java.util.ArrayList;
/**
 *
 * @author Admin
 */



public class HandEvaluator
{
  public int compareHands(PokerHands hand1, ArrayList<Card> allCards1, PokerHands hand2, ArrayList<Card> allCards2)
  {
    if (hand1.getValue() > hand2.getValue()) {
      return 1;
    }
    if (hand2.getValue() > hand1.getValue()) {
      return 2;
    }
    int card1HighCard = ((Card)highCard(hand1.getArrayList()).get(0)).getGradeAceHigh();
    int card2HighCard = ((Card)highCard(hand2.getArrayList()).get(0)).getGradeAceHigh();
    if (card1HighCard > card2HighCard) {
      return 1;
    }
    if (card2HighCard > card1HighCard) {
      return 2;
    }
    ArrayList<Card> hand1Kickers = removeHandCardsFromCards(hand1.getArrayList(), allCards1);
    ArrayList<Card> hand2Kickers = removeHandCardsFromCards(hand1.getArrayList(), allCards2);
    int card1Kicker = ((Card)highCard(hand1Kickers).get(0)).getGrade();
    int card2Kicker = ((Card)highCard(hand2Kickers).get(0)).getGrade();
    if (card1Kicker > card2Kicker)
    {
      hand1.setKicker((Card)highCard(hand1Kickers).get(0));
      return 1;
    }
    if (card2Kicker > card1Kicker)
    {
      hand2.setKicker((Card)highCard(hand2Kickers).get(0));
      return 2;
    }
    return 0;
  }
  
  public ArrayList<Card> removeHandCardsFromCards(ArrayList<Card> hand, ArrayList<Card> allCards)
  {
    ArrayList<Card> possibleKickers = new ArrayList();
    possibleKickers.addAll(allCards);
    for (Card c : hand) {
      if (allCards.contains(c)) {
        allCards.remove(c);
      }
    }
    return possibleKickers;
  }
  
  public PokerHands evaluate(ArrayList<Card> cards)
  {
    ArrayList<Card> cardsToEvaluate = new ArrayList();
    cardsToEvaluate.addAll(cards);
    Hand.orderArrayList(cardsToEvaluate);
    if (flush(cardsToEvaluate) != null)
    {
      if (straightFlush(cardsToEvaluate) != null)
      {
        if (straightToAce(cardsToEvaluate) != null)
        {
          PokerHands.StraightFlush straightFlushAce = new PokerHands.StraightFlush(straightToAce(cardsToEvaluate));
          return straightFlushAce;
        }
        PokerHands.StraightFlush straightFlush = new PokerHands.StraightFlush(straightFlush(cardsToEvaluate));
        return straightFlush;
      }
      if (twoThreeFourOfAKind(cardsToEvaluate) != null)
      {
        if (twoThreeFourOfAKind(cardsToEvaluate).size() == 4)
        {
          PokerHands.FourOfAKind foak = new PokerHands.FourOfAKind(twoThreeFourOfAKind(cardsToEvaluate));
          return foak;
        }
        if ((twoThreeFourOfAKind(cardsToEvaluate).size() == 3) && 
          (fullHouse(cardsToEvaluate) != null))
        {
          PokerHands.FullHouse fH = new PokerHands.FullHouse(fullHouse(cardsToEvaluate));
          return fH;
        }
      }
      PokerHands.Flush flush = new PokerHands.Flush(flush(cardsToEvaluate));
      return flush;
    }
    if (twoThreeFourOfAKind(cardsToEvaluate) != null)
    {
      if (twoThreeFourOfAKind(cardsToEvaluate).size() == 4)
      {
        PokerHands.FourOfAKind foak = new PokerHands.FourOfAKind(twoThreeFourOfAKind(cardsToEvaluate));
        return foak;
      }
      if (twoThreeFourOfAKind(cardsToEvaluate).size() == 3)
      {
        if (fullHouse(cardsToEvaluate) != null)
        {
          PokerHands.FullHouse fH = new PokerHands.FullHouse(fullHouse(cardsToEvaluate));
          return fH;
        }
        if (straight(cardsToEvaluate) != null)
        {
          PokerHands.Straight straight = new PokerHands.Straight(cardsToEvaluate);
          return straight;
        }
        PokerHands.ThreeOfAKind toak = new PokerHands.ThreeOfAKind(twoThreeFourOfAKind(cardsToEvaluate));
        return toak;
      }
    }
    if (straight(cardsToEvaluate) != null)
    {
      if (straightToAce(cardsToEvaluate) != null)
      {
        PokerHands.StraightFlush straightFlushAce = new PokerHands.StraightFlush(straightToAce(cardsToEvaluate));
        return straightFlushAce;
      }
      PokerHands.Straight straight = new PokerHands.Straight(cardsToEvaluate);
      return straight;
    }
    if (pair(cardsToEvaluate) != null)
    {
      if (twoPair(cardsToEvaluate) != null)
      {
        PokerHands.TwoPair twoPair = new PokerHands.TwoPair(twoPair(cardsToEvaluate));
        return twoPair;
      }
      PokerHands.OnePair pair = new PokerHands.OnePair(pair(cardsToEvaluate));
      return pair;
    }
    PokerHands.Highcard highcard = new PokerHands.Highcard(highCard(cardsToEvaluate));
    return highcard;
  }
  
  public PokerHands naiveEvaluate(ArrayList<Card> cards)
  {
    ArrayList<Card> cardsToEvaluate = new ArrayList();
    cardsToEvaluate.addAll(cards);
    Hand.orderArrayList(cardsToEvaluate);
    if ((straightFlush(cardsToEvaluate) != null) && 
      (straightToAce(cardsToEvaluate) != null))
    {
      PokerHands.StraightFlush straightFlushAce = new PokerHands.StraightFlush(straightToAce(cardsToEvaluate));
      return straightFlushAce;
    }
    if (straightFlush(cardsToEvaluate) != null)
    {
      PokerHands.StraightFlush straightFlush = new PokerHands.StraightFlush(straightFlush(cardsToEvaluate));
      return straightFlush;
    }
    if ((twoThreeFourOfAKind(cardsToEvaluate) != null) && (twoThreeFourOfAKind(cardsToEvaluate).size() == 4))
    {
      PokerHands.FourOfAKind foak = new PokerHands.FourOfAKind(twoThreeFourOfAKind(cardsToEvaluate));
      return foak;
    }
    if ((twoThreeFourOfAKind(cardsToEvaluate) != null) && (twoThreeFourOfAKind(cardsToEvaluate).size() == 3) && 
      (fullHouse(cardsToEvaluate) != null))
    {
      PokerHands.FullHouse fH = new PokerHands.FullHouse(fullHouse(cardsToEvaluate));
      return fH;
    }
    if (flush(cardsToEvaluate) != null)
    {
      PokerHands.Flush flush = new PokerHands.Flush(flush(cardsToEvaluate));
      return flush;
    }
    if (straight(cardsToEvaluate) != null)
    {
      PokerHands.Straight straight = new PokerHands.Straight(cardsToEvaluate);
      return straight;
    }
    if ((twoThreeFourOfAKind(cardsToEvaluate) != null) && (twoThreeFourOfAKind(cardsToEvaluate).size() == 3))
    {
      PokerHands.ThreeOfAKind toak = new PokerHands.ThreeOfAKind(twoThreeFourOfAKind(cardsToEvaluate));
      return toak;
    }
    if ((pair(cardsToEvaluate) != null) && 
      (twoPair(cardsToEvaluate) != null))
    {
      PokerHands.TwoPair twoPair = new PokerHands.TwoPair(twoPair(cardsToEvaluate));
      return twoPair;
    }
    if (pair(cardsToEvaluate) != null)
    {
      PokerHands.OnePair pair = new PokerHands.OnePair(pair(cardsToEvaluate));
      return pair;
    }
    PokerHands.Highcard highcard = new PokerHands.Highcard(highCard(cardsToEvaluate));
    return highcard;
  }
  
  public Card[] concatenateCardsToArray(Hand hand, Table table)
  {
    Card[] sevenCardHand = new Card[7];
    
    int counter = 0;
    for (Card x : hand.getDealtCards())
    {
      sevenCardHand[counter] = x;
      counter++;
    }
    for (Card x : table.getTableCards())
    {
      sevenCardHand[counter] = x;
      counter++;
    }
    return sevenCardHand;
  }
  
  public ArrayList<Card> concatenateCardsToArrayList(Hand hand, Table table)
  {
    ArrayList<Card> sevenCardHand = new ArrayList();
    for (Card x : hand.getDealtCards()) {
      sevenCardHand.add(x);
    }
    for (Card x : table.getTableCards()) {
      sevenCardHand.add(x);
    }
    return sevenCardHand;
  }
  
  public ArrayList<Card> highCard(ArrayList<Card> cards)
  {
    ArrayList<Card> highCards = new ArrayList();
    Hand.orderArrayList(cards);
    Card temp = (Card)cards.get(0);
    for (Card c : cards)
    {
      if (c.getGrade() == 0)
      {
        highCards.add(c);
        return highCards;
      }
      if (c.getGrade() > temp.getGrade()) {
        temp = c;
      }
    }
    highCards.add(temp);
    return highCards;
  }
  
  public ArrayList<Card> pair(ArrayList<Card> cards)
  {
    ArrayList<Card> pair = new ArrayList();
    Hand.orderByGradeAcesLast(cards);
    for (int i = 0; i < cards.size(); i++) {
      for (int j = i + 1; j < cards.size(); j++) {
        if (((Card)cards.get(j)).getGrade() == ((Card)cards.get(i)).getGrade())
        {
          pair.add((Card)cards.get(j));
          pair.add((Card)cards.get(i));
          return pair;
        }
      }
    }
    return null;
  }
  
  public ArrayList<Card> twoPair(ArrayList<Card> cards)
  {
    Hand.orderByGradeAcesLast(cards);
    ArrayList<Card> temp = new ArrayList();
    ArrayList<Card> firstPair = new ArrayList();
    temp.addAll(cards);
    firstPair.addAll(pair(temp));
    temp.removeAll(pair(cards));
    if (pair(temp) != null)
    {
      ArrayList<Card> secondPair = pair(temp);
      firstPair.addAll(0, secondPair);
      return firstPair;
    }
    return null;
  }
  
  public ArrayList<Card> threeOfAKind(ArrayList<Card> cards)
  {
    ArrayList<Card> temp = new ArrayList();
    for (int i = 0; i < cards.size(); i++) {
      for (int j = i + 1; j < cards.size(); j++) {
        if (((Card)cards.get(j)).getGrade() == ((Card)cards.get(i)).getGrade()) {
          for (int k = j + 1; k < cards.size(); k++) {
            if ((((Card)cards.get(j)).getGrade() == ((Card)cards.get(i)).getGrade()) && (((Card)cards.get(j)).getGrade() == ((Card)cards.get(k)).getGrade()))
            {
              temp.add((Card)cards.get(i));
              temp.add((Card)cards.get(j));
              temp.add((Card)cards.get(k));
              return temp;
            }
          }
        }
      }
    }
    return null;
  }
  
  public ArrayList<Card> fourOfAKind(ArrayList<Card> cards)
  {
    ArrayList<Card> temp = new ArrayList();
    for (int i = 0; i < cards.size(); i++) {
      for (int j = i + 1; j < cards.size(); j++) {
        if (((Card)cards.get(j)).getGrade() == ((Card)cards.get(i)).getGrade()) {
          for (int k = j + 1; k < cards.size(); k++) {
            if ((((Card)cards.get(j)).getGrade() == ((Card)cards.get(i)).getGrade()) && (((Card)cards.get(i)).getGrade() == ((Card)cards.get(k)).getGrade())) {
              for (int m = k + 1; m < cards.size(); m++) {
                if ((((Card)cards.get(m)).getGrade() == ((Card)cards.get(i)).getGrade()) && (((Card)cards.get(j)).getGrade() == ((Card)cards.get(i)).getGrade()) && (((Card)cards.get(i)).getGrade() == ((Card)cards.get(k)).getGrade()))
                {
                  temp.add((Card)cards.get(m));
                  temp.add((Card)cards.get(i));
                  temp.add((Card)cards.get(j));
                  temp.add((Card)cards.get(k));
                  return temp;
                }
              }
            }
          }
        }
      }
    }
    return null;
  }
  
  public ArrayList<Card> twoThreeFourOfAKind(ArrayList<Card> cards)
  {
    ArrayList<Card> temp = new ArrayList();
    for (int i = 0; i < cards.size(); i++) {
      for (int j = i + 1; j < cards.size(); j++) {
        if (((Card)cards.get(j)).getGrade() == ((Card)cards.get(i)).getGrade())
        {
          for (int k = j + 1; k < cards.size(); k++) {
            if ((((Card)cards.get(j)).getGrade() == ((Card)cards.get(i)).getGrade()) && (((Card)cards.get(i)).getGrade() == ((Card)cards.get(k)).getGrade()))
            {
              for (int m = k + 1; m < cards.size(); m++) {
                if ((((Card)cards.get(m)).getGrade() == ((Card)cards.get(i)).getGrade()) && (((Card)cards.get(j)).getGrade() == ((Card)cards.get(i)).getGrade()) && (((Card)cards.get(i)).getGrade() == ((Card)cards.get(k)).getGrade()))
                {
                  temp.add((Card)cards.get(m));
                  temp.add((Card)cards.get(i));
                  temp.add((Card)cards.get(j));
                  temp.add((Card)cards.get(k));
                  return temp;
                }
              }
              temp.add((Card)cards.get(i));
              temp.add((Card)cards.get(j));
              temp.add((Card)cards.get(k));
              return temp;
            }
          }
          temp.add((Card)cards.get(i));
          temp.add((Card)cards.get(j));
          return temp;
        }
      }
    }
    return null;
  }
  
  public ArrayList<Card> removeThreeOfAKind(ArrayList<Card> cards)
  {
    ArrayList<Card> temp = new ArrayList();
    temp.addAll(cards);
    for (int i = 0; i < temp.size(); i++) {
      for (int j = i + 1; j < temp.size(); j++) {
        if (((Card)temp.get(j)).getGrade() == ((Card)temp.get(i)).getGrade()) {
          for (int k = j + 1; k < temp.size(); k++) {
            if ((((Card)temp.get(j)).getGrade() == ((Card)temp.get(i)).getGrade()) && (((Card)temp.get(i)).getGrade() == ((Card)temp.get(k)).getGrade()))
            {
              temp.remove(k);
              temp.remove(j);
              temp.remove(i);
              return temp;
            }
          }
        }
      }
    }
    return null;
  }
  
  public ArrayList<Card> fullHouse(ArrayList<Card> cards)
  {
    ArrayList<Card> TOAK = new ArrayList();
    TOAK.addAll(removeThreeOfAKind(cards));
    if (pair(TOAK) != null)
    {
      TOAK.addAll(pair(cards));
      return TOAK;
    }
    return null;
  }
  
  public ArrayList<Card> straight(ArrayList<Card> cards)
  {
    Hand.orderByGrade(cards);
    ArrayList<Card> temp = new ArrayList();
    temp.addAll(cards);
    for (int a = 0; a < temp.size() - 1; a++) {
      if (((Card)temp.get(a)).getGrade() == ((Card)temp.get(a + 1)).getGrade())
      {
        temp.remove(a + 1);
        a--;
      }
    }
    if (temp.size() >= 5)
    {
      ArrayList<Card> straightCards = new ArrayList();
      for (int i = 7 - temp.size(); i < 2; i++) {
        if ((((Card)temp.get(i)).getGrade() - ((Card)temp.get(i + 1)).getGrade() == -1) && 
          (((Card)temp.get(i)).getGrade() - ((Card)temp.get(i + 2)).getGrade() == -2) && 
          (((Card)temp.get(i)).getGrade() - ((Card)temp.get(i + 3)).getGrade() == -3) && 
          (((Card)temp.get(i)).getGrade() - ((Card)temp.get(i + 4)).getGrade() == -4))
        {
          straightCards.add((Card)temp.get(i));
          straightCards.add((Card)temp.get(i + 1));
          straightCards.add((Card)temp.get(i + 2));
          straightCards.add((Card)temp.get(i + 3));
          straightCards.add((Card)temp.get(i + 4));
          return straightCards;
        }
      }
    }
    return null;
  }
  
  public void removeDuplicateRanks(ArrayList<Card> temp)
  {
    for (int a = 0; a < temp.size() - 1; a++) {
      if (((Card)temp.get(a)).getGrade() == ((Card)temp.get(a + 1)).getGrade())
      {
        temp.remove(a + 1);
        a--;
      }
    }
  }
  
  public ArrayList<Card> straightToAce(ArrayList<Card> cards)
  {
    ArrayList<Card> straightToAceCards = new ArrayList();
    if ((Hand.containsGrade(cards, 0) != null) && 
      (Hand.containsGrade(cards, 12) != null) && 
      (Hand.containsGrade(cards, 11) != null) && 
      (Hand.containsGrade(cards, 10) != null) && 
      (Hand.containsGrade(cards, 9) != null))
    {
      straightToAceCards.add(Hand.containsGrade(cards, 9));
      straightToAceCards.add(Hand.containsGrade(cards, 10));
      straightToAceCards.add(Hand.containsGrade(cards, 11));
      straightToAceCards.add(Hand.containsGrade(cards, 12));
      straightToAceCards.add(Hand.containsGrade(cards, 0));
      return straightToAceCards;
    }
    return null;
  }
  
  public ArrayList<Card> flush(ArrayList<Card> cards)
  {
    ArrayList<Card> flushCards = new ArrayList();
    Hand.orderBySuit(cards);
    for (int i = 0; i < 3; i++) {
      if ((((Card)cards.get(i)).getSuit() == ((Card)cards.get(i + 1)).getSuit()) && 
        (((Card)cards.get(i)).getSuit() == ((Card)cards.get(i + 2)).getSuit()) && 
        (((Card)cards.get(i)).getSuit() == ((Card)cards.get(i + 3)).getSuit()) && 
        (((Card)cards.get(i)).getSuit() == ((Card)cards.get(i + 4)).getSuit()))
      {
        flushCards.add((Card)cards.get(i));
        flushCards.add((Card)cards.get(i + 1));
        flushCards.add((Card)cards.get(i + 2));
        flushCards.add((Card)cards.get(i + 3));
        flushCards.add((Card)cards.get(i + 4));
        return flushCards;
      }
    }
    return null;
  }
  
  public ArrayList<Card> straightFlush(ArrayList<Card> cards)
  {
    return straight(cards);
  }
  
  public ArrayList<PokerHands> evaluateFlopCards(ArrayList<Card> cards)
  {
    ArrayList<PokerHands> hands = new ArrayList();
    if (threeOfAKind(cards) != null)
    {
      System.out.println("toak");
      PokerHands.ThreeOfAKind toak = new PokerHands.ThreeOfAKind(cards);
      hands.add(toak);
    }
    else if (pair(cards) != null)
    {
      PokerHands.OnePair pair = new PokerHands.OnePair(cards);
      hands.add(pair);
      System.out.println("pair");
    }
    if (flopStraight(cards) != null)
    {
      PokerHands.Straight straight = new PokerHands.Straight(cards);
      hands.add(straight);
      System.out.println("straight");
    }
    if (flushTableCardsFlop(cards) != null)
    {
      PokerHands.Flush flush = new PokerHands.Flush(cards);
      hands.add(flush);
      System.out.println("flush");
    }
    return hands;
  }
  
  public ArrayList<Card> flopStraight(ArrayList<Card> cards)
  {
    Hand.orderByGrade(cards);
    ArrayList<Card> temp = new ArrayList();
    temp.addAll(cards);
    for (int a = 0; a < temp.size() - 1; a++) {
      if (((Card)temp.get(a)).getGrade() == ((Card)temp.get(a + 1)).getGrade())
      {
        temp.remove(a + 1);
        a--;
      }
    }
    if ((temp.size() == 3) && 
      (((Card)temp.get(0)).getGrade() - ((Card)temp.get(2)).getGrade() <= -4)) {
      return temp;
    }
    return temp;
  }
  
  public boolean flopFlush(ArrayList<Card> cards)
  {
    Hand.orderBySuit(cards);
    if ((((Card)cards.get(0)).getSuit() == ((Card)cards.get(1)).getSuit()) && 
      (((Card)cards.get(1)).getSuit() == ((Card)cards.get(2)).getSuit())) {
      return true;
    }
    return false;
  }
  
  public ArrayList<Card> flushTableCardsFlop(ArrayList<Card> cards)
  {
    ArrayList<Card> flushCards = new ArrayList();
    Hand.orderBySuit(cards);
    for (int i = 0; i < 3; i++) {
      if ((((Card)cards.get(i)).getSuit() == ((Card)cards.get(i + 1)).getSuit()) && (((Card)cards.get(i)).getSuit() == ((Card)cards.get(i + 2)).getSuit()))
      {
        flushCards.add((Card)cards.get(i));
        flushCards.add((Card)cards.get(i + 1));
        flushCards.add((Card)cards.get(i + 2));
      }
    }
    return null;
  }
  
  public ArrayList<Card> straightTableCards(ArrayList<Card> cards)
  {
    if (cards.get(0) == null) {
      return null;
    }
    Hand.orderByGrade(cards);
    ArrayList<Card> temp = new ArrayList();
    temp.addAll(cards);
    for (int a = 0; a < temp.size() - 1; a++) {
      if (((Card)temp.get(a)).getGrade() == ((Card)temp.get(a + 1)).getGrade())
      {
        temp.remove(a + 1);
        a--;
      }
    }
    if (temp.size() >= 3) {
      for (int i = 0; i < temp.size() - 2; i++)
      {
        ArrayList<Card> straightCards = new ArrayList();
        if (((Card)temp.get(i)).getGrade() - ((Card)temp.get(i + 2)).getGrade() >= -4)
        {
          straightCards.add((Card)temp.get(i));
          straightCards.add((Card)temp.get(i + 1));
          straightCards.add((Card)temp.get(i + 2));
          return straightCards;
        }
      }
    }
    return null;
  }
  
  public ArrayList<Card> straightFlushTableCards(ArrayList<Card> cards)
  {
    if ((cards.size() < 3) || (straightTableCards(cards) == null) || (flushTableCardsFlop(cards) == null)) {
      return null;
    }
    return straightTableCards(flushTableCardsFlop(cards));
  }
}
