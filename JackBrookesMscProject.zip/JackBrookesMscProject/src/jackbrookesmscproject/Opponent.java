
package jackbrookesmscproject;

import java.util.ArrayList;

/**
 *
 * @author JZB3
 */
public abstract interface Opponent {
    
    public abstract void playCards(int paramInt);
    
    public abstract void preFlopMove(int paramInt);
    
    public abstract void postFlopMove(int paramInt);
    
    public abstract void makeChoice(int paramInt1, int paramInt2);
    
    public abstract PlayerType getPlayerType();
    
    public abstract void dealHand(Deck paramDeck);
    
    public abstract Hand returnHand();
    
    public abstract void clearHand();
    
    public abstract ArrayList<Card> getHand();
    
    public abstract String getName();
    

    
    public static class tightAggressiveOpponent extends Player implements Opponent
    {
        private Hand playerHand;
        private final HandEvaluator handEval = new HandEvaluator();
        private final Table table;
        private PlayerType playerType = PlayerType.TIGHTAGGRESSIVE;
        
        public tightAggressiveOpponent(String name, boolean bool, Pot pot, Table table)
        {
           super(name, bool, pot, Boolean.valueOf(false));
            this.table = table;
            this.playerType = PlayerType.TIGHTAGGRESSIVE;
        }
        
        /**
        * @return PlayerType
        */
        @Override
        public PlayerType getPlayerType()
        {
            return this.playerType;
        }
        
         /**
        * @return String
        */
        @Override
        public String getName()
        {
        return this.name;
        }
        
         /**
        * @param choices
        */
        @Override
        public void playCards(int choices)
        {
            if((Math.random() >= 0.95D) && (
                    (((Card)this.playerHand.getDealtCards().get(0)).getGradeAceHigh() + ((Card)this.playerHand.getDealtCards().get(1)).getGradeAceHigh() > 18) ||
                    (this.handEval.pair(this.playerHand.getDealtCards()) != null) ||
                    (((Card)this.playerHand.getDealtCards().get(0)).getSuit() == ((Card)this.playerHand.getDealtCards().get(1)).getSuit()) ||
                    (((Card)this.playerHand.getDealtCards().get(0)).getGrade() - ((Card)this.playerHand.getDealtCards().get(1)).getGrade() >= -4) ||
                    (((Card)this.playerHand.getDealtCards().get(0)).getGradeAceHigh() - ((Card)this.playerHand.getDealtCards().get(1)).getGradeAceHigh() >= -4)))
            {
                if (choices == 3){
                    //call
                    call(((Player)getOpponent()), player);
                }
                //raise
                largeBet(false, 0);
            }
            switch (choices)
            {
                case 1:
                    //raise
                    smallBet(false, 0);
                    break;
                case 2:
                    //raise
                    largeBet(false, 0);
                    break;
                case 3:
                    //call
                    call(((Player)getOpponent()), player);
                    break;
                   
                default: 
                    //fold
                    fold(((Player)getOpponent()), player, getPot());
            }  
        }
        
         /**
        * @param choices
        */
        @Override
        public void preFlopMove(int choices)
        {
            switch (choices)
            {
                case 1:
                    smallBet(false, 0);
                case 2:
                    largeBet(false, 0);
                case 3:
                    call(((Player)getOpponent()), player);
            }
            //fold
            fold(((Player)getOpponent()), player, getPot());
        }
        
         /**
        * @param choices
        */
        @Override
        public void postFlopMove(int choices)
        {
            ArrayList<Card> temp = this.handEval.concatenateCardsToArrayList(this.playerHand, this.table);
            if(Math.random() > 0.9D)
            {
                if((this.handEval.evaluate(temp) instanceof PokerHands.Highcard))
                {
                    fold(((Player)getOpponent()), player, getPot());
                }
                if(((this.handEval.evaluate(temp) instanceof PokerHands.OnePair)) && (((Card)this.playerHand.getDealtCards().get(0)).getGradeAceHigh() >= 6))
                {
                    fold(((Player)getOpponent()), player, getPot());
                }
            }
            if(choices == 3){
                call(((Player)getOpponent()), player);
            }
            if(choices == 2)
            {
                if (Math.random() >= 0.8D)
                {
                    largeBet(false, 0);
                }
                //check
                check(((Player)getOpponent()), getPot());
            }
            if(choices == 1)
            {
                if(Math.random() >= 0.95D)
                {
                    //raise
                    smallBet(false, 0);
                }
                //call
                call(((Player)getOpponent()), player);
            }
            //fold
            else{
                fold(((Player)getOpponent()), player, getPot());
            }
        }
        
         /**
        * @param round
        * @param choices
        */
        @Override
        public void makeChoice(int round, int choices)
        {
            try
            {
                Thread.sleep(1500L);
            }
            catch (Exception localException) {}
            if (round == 0)
            {
                playCards(choices);
            }
            if (round == 1)
            {
                preFlopMove(choices);
            }
            if (round == 2)
            {
                postFlopMove(choices);
            } 
            
        }
        
        /**
        * @param deck
        */
        @Override
        public void dealHand(Deck deck)
        {
            this.playerHand = new Hand(deck);
        }
        
        /**
        * @return Hand
        */
        @Override
        public Hand returnHand()
        {
            return this.playerHand;
        }
        
        /**
        * @return ArrayList
        */
        @Override
         public ArrayList<Card> getHand()
        {
            return this.playerHand.getDealtCards();
        }
        
        @Override
        public void clearHand()
        {
            this.playerHand.clearHand();
        }
        
    }
    
        public static class looseAggressiveOpponent extends Player implements Opponent
        {
            private Hand playerHand;
            private final HandEvaluator hE = new HandEvaluator();
            private final Table table;
            private PlayerType playerType = PlayerType.LOOSEAGGRESSIVE;
        
        public looseAggressiveOpponent(String name, boolean bool, Pot pot, Table table)
        {
             super(name, bool, pot, Boolean.valueOf(false));
            this.table = table;
            this.playerType = PlayerType.LOOSEAGGRESSIVE;
            }
        /**
        * @return PlayerType
        */
            @Override
        public PlayerType getPlayerType()
        {
            return PlayerType.LOOSEAGGRESSIVE;
        }
        
         /**
        * @return String
        */
        @Override
        public String getName()
        {
            return this.name;
        }
        
         /**
        * @param choices
        */
            @Override
        public void playCards(int choices)
        {
            switch (choices)
            {
                case 1:
                    smallBet(false, 0);
                case 2:
                    largeBet(false, 0);
                case 3:
                    call(((Player)getOpponent()), player);
            }
            fold(((Player)getOpponent()), player, getPot());
        }
        
         /**
        * @param choices
        */
            @Override
        public void preFlopMove(int choices)
        {
            switch (choices)
            {
                case 1:
                    smallBet(false, 0);
                case 2:
                    largeBet(false, 0);
                case 3:
                    call(((Player)getOpponent()), player);
            }
            fold(((Player)getOpponent()), player, getPot());
        }
        
         /**
        * @param choices
        */
            @Override
        public void postFlopMove(int choices)
        {
            if (choices == 3)
            {
                call(((Player)getOpponent()), player);
            }
            if (choices == 2)
            {
                if(Math.random() >= 0.8D)
                {
                    smallBet(false, 0);
                }
                check(((Player)getOpponent()), getPot());
            }
            if (choices == 1)
            {
                if(Math.random() >= 0.95D)
                {
                    largeBet(false, 0);
                }
                call(((Player)getOpponent()), player);
            }
            fold(((Player)getOpponent()), player, getPot());
        }
        
        /**
        * @param round
        * @param choices
        */
            @Override
        public void makeChoice(int round, int choices)
        {
            try
            {
                Thread.sleep(1500L);
            }
            catch (Exception localException) {}
            if (round == 0)
            {
                playCards(choices);
            }
            if (round == 1)
            {
                preFlopMove(choices);
            }
            if (round == 2)
            {
                postFlopMove(choices);
            } 
            else{
            
                fold(((Player)getOpponent()), player, getPot());
            }
        }
        
        /**
        * @param deck
        */
            @Override
        public void dealHand(Deck deck)
        {
            this.playerHand = new Hand (deck);
        }
        
        /**
        * @return Hand
        */
            @Override
        public Hand returnHand()
        {
            return this.playerHand;
        }
        
         /**
        * @return ArrayList
        */
        @Override
         public ArrayList<Card> getHand()
        {
            return this.playerHand.getDealtCards();
        }
        
            @Override
        public void clearHand()
        {
            this.playerHand.clearHand();
        }
    }
    
        public static class tightPassiveOpponent extends Player implements Opponent
        {
            private Hand playerHand;
            private final HandEvaluator hE = new HandEvaluator();
            private final Table table;
            private PlayerType playStyle = PlayerType.TIGHTPASSIVE;
        
        public tightPassiveOpponent(String name, boolean bool, Pot pot, Table table)
        {
            super(name, bool, pot, Boolean.valueOf(false));
            this.playStyle = PlayerType.TIGHTPASSIVE;
            this.table = table;
        }
        
        /**
        * @return PlayerType
        */
            @Override
        public PlayerType getPlayerType()
        {
            return PlayerType.TIGHTPASSIVE;
        }
        
         /**
        * @return String
        */
        @Override
        public String getName()
        {
        return this.name;
        }
        
         /**
        * @param choices
        */
            @Override
        public void playCards (int choices)
        {
            if ((((Card)this.playerHand.getDealtCards().get(0)).getGradeAceHigh() + ((Card)this.playerHand.getDealtCards().get(1)).getGradeAceHigh() > 18) ||
                    (this.hE.pair(this.playerHand.getDealtCards()) != null) ||
                    (((Card)this.playerHand.getDealtCards().get(0)).getSuit() == ((Card)this.playerHand.getDealtCards().get(1)).getSuit()) ||
                    (((Card)this.playerHand.getDealtCards().get(0)).getGrade() - ((Card)this.playerHand.getDealtCards().get(1)).getGrade() >= - 4) ||
                    (((Card)this.playerHand.getDealtCards().get(0)).getGradeAceHigh() - ((Card)this.playerHand.getDealtCards().get(1)).getGradeAceHigh() >= -4))
                    {
                        switch (choices)
                        {
                    case 1:
                        call(((Player)getOpponent()), player);
                    case 2:
                        check(((Player)getOpponent()), getPot());
                    case 3:
                        call(((Player)getOpponent()), player);
            }
                    } else {
                            fold(((Player)getOpponent()), player, getPot());
                                }
                        fold(((Player)getOpponent()), player, getPot());
                    }
        
         /**
        * @param choices
        */
            @Override
        public void preFlopMove(int choices)
        {
            ArrayList<Card> temp = this.hE.concatenateCardsToArrayList(this.playerHand, this.table);
            if ((this.hE.flopFlush(temp)) || (this.hE.flopStraight(temp) != null) || (this.hE.pair(temp) != null))
                    {
                        if ((choices == 1) || (choices == 2))
                        {
                            largeBet(false, 0);
                        }
                        if (choices == 3){
                            call(((Player)getOpponent()), player);
                        }
                    }
            switch (choices)
            {
                case 1:
                    call(((Player)getOpponent()), player);
                case 2:
                    check(((Player)getOpponent()), getPot());
                case 3:
                    call(((Player)getOpponent()), player);
            }
            fold(((Player)getOpponent()), player, getPot());
        }
        
         /**
        * @param choices
        */
            @Override
        public void postFlopMove(int choices)
        {
            ArrayList<Card> temp = this.hE.concatenateCardsToArrayList(this.playerHand, this.table);
            if (((this.hE.evaluate(temp)instanceof PokerHands.StraightFlush)) || ((this.hE.evaluate(temp) instanceof PokerHands.FourOfAKind)) ||
                    ((this.hE.evaluate(temp) instanceof PokerHands.FullHouse)) || ((this.hE.evaluate(temp) instanceof PokerHands.Flush)) ||
                    ((this.hE.evaluate(temp) instanceof PokerHands.Straight)) || ((this.hE.evaluate(temp) instanceof PokerHands.ThreeOfAKind)))
            {
                call(((Player)getOpponent()), player);
            }
            call(((Player)getOpponent()), player);
        }
        
        /**
        * @param round
        * @param choices
        */
            @Override
        public void makeChoice(int round, int choices)
        {
            try
            {
                Thread.sleep(1500L);
            }
            catch (Exception localException) {}
            if (round == 0)
            {
                playCards(choices);
            }
            if (round == 1)
            {
                preFlopMove(choices);
            }
            if (round == 2)
            {
                postFlopMove(choices);
            } 
            else{
            
                fold(((Player)getOpponent()), player, getPot());
            }
        }
        /**
        * @param deck
        */
            @Override
        public void dealHand(Deck deck)
        {
            this.playerHand = new Hand(deck);
        }
        
         /**
        * @return ArrayList
        */
            @Override
         public ArrayList<Card> getHand()
        {
            return this.playerHand.getDealtCards();
        }
        
         /**
        * @return Hand
        */
            @Override
        public Hand returnHand()
        {
            return this.playerHand;
        }
        
        /**
         *
         */
        public void clearHand()
        {
            this.playerHand.clearHand();
        }
    }
    
        public static class loosePassiveOpponent extends Player implements Opponent
        {
             private Hand playerHand;
            private final HandEvaluator hE = new HandEvaluator();
            private final Table table;
            private PlayerType playerType = PlayerType.LOOSEPASSIVE;
        
        public loosePassiveOpponent(String name, boolean bool, Pot pot, Table table)
        {
            super(name, bool, pot, Boolean.valueOf(false));
            this.playerType = PlayerType.LOOSEPASSIVE;
            this.table = table;
        }
        
        /**
        * @return PlayerType
        */
            @Override
        public PlayerType getPlayerType()
        {
            return PlayerType.LOOSEPASSIVE;
        }
        
         /**
        * @return String
        */
        @Override
        public String getName()
        {
        return this.name;
        }
        
         /**
        * @param choices
        */
            @Override
        public void playCards(int choices)
        {
            switch (choices)
            {
                case 1:
                    call(((Player)getOpponent()), player);
                case 2:
                    check(((Player)getOpponent()), getPot());
                case 3:
                    call(((Player)getOpponent()), player);
            }
            fold(((Player)getOpponent()), player, getPot());
        }
        
         /**
        * @param choices
        */
            @Override
        public void preFlopMove(int choices)
        {
            ArrayList<Card> temp = this.hE.concatenateCardsToArrayList(this.playerHand, this.table);
            if((this.hE.flopFlush(temp)) || (this.hE.flopStraight(temp) != null) || (this.hE.flopStraight(temp) != null) || (this.hE.pair(temp) != null))
            {
                switch (choices)
                {
                    case 1:
                        largeBet(false, 0);
                    case 2:
                        smallBet(false, 0);
                    case 3:
                        call(((Player)getOpponent()), player);
                }
            }
            switch (choices)
            {
                case 1:
                    call(((Player)getOpponent()), player);
                case 2:
                    check(((Player)getOpponent()), getPot());
                case 3:
                    call(((Player)getOpponent()), player);
            }
            fold(((Player)getOpponent()), player, getPot());
        }
        
         /**
        * @param choices
        */
            @Override
        public void postFlopMove(int choices)
        {
           ArrayList<Card> temp = this.hE.concatenateCardsToArrayList(this.playerHand, this.table);
           if (((this.hE.evaluate(temp) instanceof PokerHands.StraightFlush)) || ((this.hE.evaluate(temp) instanceof PokerHands.FourOfAKind)) ||
                   ((this.hE.evaluate(temp) instanceof PokerHands.FullHouse)) || ((this.hE.evaluate(temp) instanceof PokerHands.Flush)) ||
                   ((this.hE.evaluate(temp) instanceof PokerHands.Straight)) || ((this.hE.evaluate(temp) instanceof PokerHands.ThreeOfAKind)))
            {
                switch (choices)
                {
                    case 1:
                        largeBet(false, 0);
                    case 2:
                        smallBet(false, 0);
                    case 3:
                        call(((Player)getOpponent()), player);
                }
            }
                switch (choices)
                {
                    case 1:
                        call(((Player)getOpponent()), player);
                    case 2:
                        check(((Player)getOpponent()), getPot());
                    case 3:
                        call(((Player)getOpponent()), player);
                }
                fold(((Player)getOpponent()), player, getPot());
        }
        
        /**
        * @param round
        * @param choices
        */
            @Override
        public void makeChoice(int round, int choices)
        {
            try
            {
                Thread.sleep(1500L);
            }
            catch (Exception localException) {}
            if (round == 0)
            {
                playCards(choices);
            }
            if (round == 1)
            {
                preFlopMove(choices);
            }
            if (round == 2)
            {
                postFlopMove(choices);
            } 
            else{
            
                fold(((Player)getOpponent()), player, getPot());
            }
        }
        
        /**
        * @param deck
        */
            @Override
        public void dealHand(Deck deck)
        {
            this.playerHand = new Hand(deck);
        }
        
        
         /**
        * @return ArrayList
        */
        @Override
         public ArrayList<Card> getHand()
        {
            return this.playerHand.getDealtCards();
        }
        
         /**
        * @return Hand
        */
            @Override
        public Hand returnHand()
        {
            return this.playerHand;
        }
        
            @Override
        public void clearHand()
        {
            this.playerHand.clearHand();
        }
    } 
}