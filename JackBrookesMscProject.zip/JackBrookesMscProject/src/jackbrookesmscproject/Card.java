/*
 * 
 */
package jackbrookesmscproject;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author Jzb3
 */
public class Card extends ImageView 
{
    
    
  private int grade;
  private int suit;
  private static final String[] grades = { "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king" };
  private static final String[] suits = { "spades", "clubs", "hearts", "diamonds" };
  
  public static final int  SPADES    =  0;
  public static final int  CLUBS     =  1;
  public static final int  HEARTS    =  2;
  public static final int  DIAMONDS  =  3;
  Image cardFaceUpImage;

  public Card(int grade, int suit)
  {
      //Card Images need to be re-worked in here.
    this.grade = grade;
    this.suit = suit;
    ImageStore.cardBackImage = new Image("playingCardsInt/temp.gif");
        
        ImageStore.cardFaceImages = new HashMap<String, Image>();

        /*
         * A reference to an Image object will be retrieved by using
         * a string as a key. For example, with the string "spades1" the
         *image of the Ace of Spades is found.
         */

      if ( suit == HEARTS )
      {
         cardFaceUpImage = ImageStore.cardFaceImages.get("hearts" + grade ) ;
      }
      else if ( suit == DIAMONDS )
      {
         cardFaceUpImage = ImageStore.cardFaceImages.get("diamonds" + grade ) ;
      }
      else if ( suit == SPADES )
      {
         cardFaceUpImage = ImageStore.cardFaceImages.get("spades" + grade ) ;
      }
      else if ( suit == CLUBS )
      {
         cardFaceUpImage = ImageStore.cardFaceImages.get("clubs" + grade ) ;
      }

      setImage(ImageStore.cardBackImage) ; // Initially the card is face-down
      
      String[] fileNameString = { "hearts", "diamonds", "spades", "clubs" } ;
      
        for (int suitIndex = 0; suitIndex < 3; suitIndex++)
            {
            for (int cardRank = 1; cardRank < 13; cardRank++)
            {
				String imageFileName = "playingCardsInt/" + fileNameString[suitIndex]
                                   + cardRank + ".gif";

                Image faceImage = new Image(imageFileName);
                
                String key = fileNameString[suitIndex]
                                 + cardRank + ".gif";

                ImageStore.cardFaceImages.put(key, faceImage);
         }
      }
  }
  
   public int getGrade()
  {
    return this.grade;
  }
  
  public int getGradeAceHigh()
  {
    if (this.grade == 0) {
      return 14;
    }
    return this.grade;
  }
  
  public String getGradeString()
  {
    return grades[this.grade];
  }
  
  public int getSuit()
  {
    return this.suit;
  }
  
  public String getSuitString()
  {
    return suits[this.suit];
  }
  
  @Override
  public String toString()
  {
    return grades[this.grade] + " of " + suits[this.suit];
  }
  
  //returns file String name for card image construction
  public String toFileString()
  {
    return suits[this.suit] + grades[this.grade];
  }
  
 public void  turnCardFaceUp()
   {
      this.setImage(cardFaceUpImage) ;
   }
     
   public boolean  cardIsFaceUp()
   {
      return  (  getImage() == cardFaceUpImage  ) ;
   }

    public void turnCard()
   {
      if ( getImage() == cardFaceUpImage )
      {
         this.setImage(ImageStore.cardBackImage ) ;
      }
      else
      {
         this.setImage(cardFaceUpImage ) ;
      }
   }
 
}
    
    

