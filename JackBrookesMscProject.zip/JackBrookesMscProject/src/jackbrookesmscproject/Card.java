/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author Admin
 */
public class Card extends ImageView {
    
    
  private int grade;
  private int suit;
  private static final String[] grades = { "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king" };
  private static final String[] suits = { "spades", "clubs", "hearts", "diamonds" };

  
  public Card(int grade, int suit)
  {
    this.grade = grade;
    this.suit = suit;
    
  }
  
   public int getGrade()
  {
    return this.grade;
  }
  
  public int getGradeAceHigh()
  {
    if (this.grade == 0) {
      return 14;
    }
    return this.grade;
  }
  
  public String getGradeString()
  {
    return grades[this.grade];
  }
  
  public int getSuit()
  {
    return this.suit;
  }
  
  public String getSuitString()
  {
    return suits[this.suit];
  }
  
  @Override
  public String toString()
  {
    return grades[this.grade] + " of " + suits[this.suit];
  }
  
  //returns file String name for card image construction
  public String toFileString()
  {
    return suits[this.suit] + grades[this.grade];
  }
  
  public void  setCardPosition( double positionX, double positionY )
   {
      setX( positionX ) ;
      setY( positionY ) ;
   }
   
    
    }
    
    

