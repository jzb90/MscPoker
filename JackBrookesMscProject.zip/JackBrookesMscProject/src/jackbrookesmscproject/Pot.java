/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

/**
 *
 * @author Admin
 */
public class Pot
{
  private int potTotal = 0;
  
  public void addToPot(int amount)
  {
    this.potTotal += amount;
  }
  
  public void clearPot()
  {
    this.potTotal = 0;
  }
  
  public int getPotAmount()
  {
    return this.potTotal;
  }
  
  public void wonPot(Player player)
  {
    player.addChips(this.potTotal);
    player.incrementAmountWon(this.potTotal);
    this.potTotal = 0;
  }
  
  public void sharePot(Player player1, Player player2)
  {
    player1.addChips(this.potTotal / 2);
    player1.incrementAmountWon(this.potTotal / 2);
    player2.addChips(this.potTotal / 2);
    player2.incrementAmountWon(this.potTotal / 2);
  }
}
