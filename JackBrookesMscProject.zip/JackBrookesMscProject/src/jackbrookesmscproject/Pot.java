
package jackbrookesmscproject;

/**
 *
 * @author Jzb3
 */
public class Pot
{
  private int potTotal = 0;
  
  
  /**
     * @param amount
     */
  public void addToPot(int amount)
  {
    this.potTotal += amount;
  }
  
  public void clearPot()
  {
    this.potTotal = 0;
  }
  
  public int getPotAmount()
  {
    return this.potTotal;
  }
  
  
  /**
     * @param player
     */
  public void wonPot(Player player)
  {
    player.addChips(this.potTotal);
    player.incrementWinnings(this.potTotal);
    this.potTotal = 0;
  }
  
  /**
     * @param player
     * @param player2
     */
  public void sharePot(Player player, Player player2)
  {
    player.addChips(this.potTotal / 2);
    player.incrementWinnings(this.potTotal / 2);
    player2.addChips(this.potTotal / 2);
    player2.incrementWinnings(this.potTotal / 2);
  }
}
