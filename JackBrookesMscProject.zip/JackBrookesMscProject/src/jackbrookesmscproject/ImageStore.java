/*
 *This class handles the storage of the image of the card objects.
 */
package jackbrookesmscproject;

import java.util.HashMap;
import javafx.scene.image.Image;

/**
 *
 * @author Jzb3
 */
public class ImageStore
{
   static Image cardBackImage;

   static HashMap<String, Image> cardFaceImages;
}