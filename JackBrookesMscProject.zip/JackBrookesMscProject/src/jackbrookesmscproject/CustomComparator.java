/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

/**
 *
 * @author Jzb3
 */
import java.util.Comparator;

public class CustomComparator implements Comparator<Card>
{
  @Override
  public int compare(Card first, Card second)
  {
    return first.getGrade() - second.getGrade();
  }
  
  public int compareSuits(Card first, Card second)
  {
    return first.getSuit() - second.getSuit();
  }
}

