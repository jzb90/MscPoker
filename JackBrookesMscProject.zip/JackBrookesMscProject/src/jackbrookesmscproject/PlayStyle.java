/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

/**
 *
 * @author Admin
 */
public enum PlayStyle
{
  TIGHTAGGRESSIVE,  LOOSEAGGRESSIVE,  TIGHTPASSIVE,  LOOSEPASSIVE;
}
