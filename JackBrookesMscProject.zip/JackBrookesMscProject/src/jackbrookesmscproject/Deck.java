
package jackbrookesmscproject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
/**
 *
 * @author Jzb3
 */

public class Deck
{
  private ArrayList<Card> deckOfCards;
  
  public Deck()
  {
    this.deckOfCards = new ArrayList();
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 13; j++) {
        this.deckOfCards.add(new Card(j, i));
      }
    }
    Collections.shuffle(this.deckOfCards);
  }
  
  public ArrayList<Card> getDeck()
  {
    return this.deckOfCards;
  }
  
  /**
     *
     * @param card
     * @return 
     */
  
  public Boolean getCardFromDeck(Card card)
  {
    if (this.deckOfCards.contains(card)) {
      return true;
    }
    return null;
  }
  
  public void printDeck()
  {
    for (Card card : this.deckOfCards) {
      System.out.println(card.toString());
    }
  }
  
  public Card drawTopCard()
  {
    return (Card)this.deckOfCards.remove(0);
  }
  
  public Card drawRandomCard()
  {
    Random randomGenerator = new Random();
    return (Card)this.deckOfCards.remove(randomGenerator.nextInt(this.deckOfCards.size()));
  }
}

