/*
 * This class is responsible for the GUI interaction.
 */
package jackbrookesmscproject;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

/**
 *
 * @author Jzb3
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    MenuItem newGameTAopponent;
    @FXML
    MenuItem newGameTPopponent;
    @FXML
    MenuItem newGameLAopponent;
    @FXML
    MenuItem newGameLPopponent;
    @FXML
    MenuItem close;
    //Opponent area of GUI
    @FXML
    VBox opponentVBox;
    @FXML
    Label opponentNameChips;
    @FXML
    HBox opponentCards;
    //Player area of GUI
    @FXML
    VBox playerVBox;
    @FXML
    Label playerNameChips;
    @FXML
    HBox playerCards;
    //Game Information pane.
    @FXML
    Text gameInfoText;
    @FXML
    ScrollPane gameScrollPane;
    @FXML
    Button doneButton;
    //Button bar and betting actions
    @FXML
    ButtonBar gameButtonBar;
    @FXML
    Button foldButton;
    @FXML
    Button checkButton;
    @FXML
    Button callButton;
    @FXML
    Button raiseButton;
    @FXML
    TextField betText;
    //Table area of GUI
    VBox tablePotVBox;
    @FXML
    Label potInfo;
    @FXML
    HBox tableCardsArea;
    
    //Fields of game 
    
    Deck deck;
    Pot pot;
    Table table;
    Player player;
    Opponent activeOpponent;
    private static volatile int playerInput = 0;
    
    //Fields associated with images of Game

    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
      
    }
 
    /**
     *
     * @param event
     */
    @FXML
        
    public void handleDoneButtonAction(ActionEvent event) 
    {
        
       int i = 0;
       currentRound(player, activeOpponent, table, deck, pot, i);
       i++;
    }
    
    /**
     *
     * @param event
     */
    public void handleNewGameButtonAction(ActionEvent event) 
    {
       run();
    }
    
    /**
     *
     * @param event
     */
    public void handleCheckButtonAction(ActionEvent event) 
    {
       player.getPlayersTurn();
       player.check(player, pot);
       player.playersTurnToFalse();  
    }
    
    /**
     *
     * @param event
     */
    public void handleCallGameButtonAction(ActionEvent event) 
    {
        player.getPlayersTurn();
        player.call(player, (Player)activeOpponent);
	player.playersTurnToFalse();
    }
    
    
  public static void setPlayerInput(int x)
  {
    playerInput = x;
    System.out.println(playerInput);
  }
  
  public void clearPlayerCommand()
  {
    playerInput = 0;
  }
    
    /**
     *
     * @param event
     */
    public void handleRaiseButtonAction(ActionEvent event) 
    {
       player.getPlayersTurn();
	try {
			String betString = betText.getText();
			int betInt = 0;
			betInt = Integer.parseInt(betString);
	
			if (betInt > player.getChips())
		{
			gameInfoText.setText("Not enough chips...");
		} else  {
			player.raise(player, pot, betInt);
			gameInfoText.setText(player.getName() + " placed a bet of " + betInt + ", leaving them with " + player.getChips() + " chips.");
                        player.playersTurnToFalse();
		}
			} catch (NumberFormatException nfEX){
			System.out.println("Please enter a valid number."); // updateGameInfo
		}
    }
    
    /**
     *
     * @param event
     */
    public void handleFoldButtonAction(ActionEvent event) 
    {
       player.getPlayersTurn();
       player.fold(player,(Player)activeOpponent, pot);
       player.setPlayersTurn();
    }
    
    /**
     *
     * @param event
     */
    public void menuNewGameTAOpponent (ActionEvent event)
    {
      Pot pot = new Pot();
      Table table = new Table();
      Deck deck = new Deck();
      Player player = new Player("Player", false, pot, true);
      Opponent.tightAggressiveOpponent taOpponent = new Opponent.tightAggressiveOpponent("Jake (TA)", true, pot, table);
      player.setOpponentPlayStyle(PlayerType.TIGHTAGGRESSIVE);
      activeOpponent = taOpponent;
      ((Player)activeOpponent).setOpponent(player);
      player.setBotOpponent(activeOpponent);
      playGame(player, activeOpponent, table, deck, pot);
    }
    
    /**
     *
     * @param event
     */
    public void menuNewGameTPOpponent (ActionEvent event)
    {
      Pot pot = new Pot();
      Table table = new Table();
      Deck deck = new Deck();
      Player player = new Player("Player", false, pot, true);
      Opponent.tightPassiveOpponent tpOpponent = new Opponent.tightPassiveOpponent("Tom (TP)", true, pot, table);
      player.setOpponentPlayStyle(PlayerType.TIGHTPASSIVE);
      activeOpponent = tpOpponent;
      ((Player)activeOpponent).setOpponent(player);
      player.setOpponent(((Player)activeOpponent));
      playGame(player, activeOpponent, table, deck, pot);
    }
    
    /**
     *
     * @param event
     */
    public void menuNewGameLAOpponent (ActionEvent event)
    {
      Pot pot = new Pot();
      Table table = new Table();
      Deck deck = new Deck();
      Player player = new Player("Player", false, pot, true);
      Opponent.looseAggressiveOpponent laOpponent = new Opponent.looseAggressiveOpponent("Laura (LA)", true, pot, table);
      player.setOpponentPlayStyle(PlayerType.LOOSEAGGRESSIVE);
      activeOpponent = laOpponent;
      ((Player)activeOpponent).setOpponent(player);
      player.setOpponent(((Player)activeOpponent));
      playGame(player, activeOpponent, table, deck, pot);
    }
    
    /**
     *
     * @param event
     */
    public void menuNewGameLPOpponent (ActionEvent event)
    {
      Pot pot = new Pot();
      Table table = new Table();
      Deck deck = new Deck();
      Player player = new Player("Player", false, pot, true);
      Opponent.loosePassiveOpponent lpOpponent = new Opponent.loosePassiveOpponent("Larry (LP)", true, pot, table);
      player.setOpponentPlayStyle(PlayerType.LOOSEPASSIVE);
      activeOpponent = lpOpponent;
      ((Player)activeOpponent).setOpponent(player);
      player.setOpponent(((Player)activeOpponent));
      playGame(player, activeOpponent, table, deck, pot);
    }
    
    /**
     *
     * @param one
     * @param two
     * @param three
     * @param four
     * @param five
     * @param six
     */
    @FXML
    public void toggleButtonDisplay(boolean one, boolean two, boolean three, boolean four, boolean five, boolean six)
    {
        foldButton.setDisable(one);
        checkButton.setDisable(two);
        callButton.setDisable(three);
        raiseButton.setDisable(four);
        betText.setDisable(five);
        doneButton.setDisable(six);
    }
      
    /**
     *
     */
    public void run()
    {
      
    } 
    
    /**
     *
     * @param player
     * @param opponent
     * @param table
     * @param deck
     * @param pot
     */
    public void playGame(Player player, Opponent opponent, Table table, Deck deck, Pot pot)
    {
        potInfo.setText("Pot: " +  pot.getPotAmount());
        playerNameChips.setText(player.getName() + "n/" + "Chips:" + player.getChips());
        opponentNameChips.setText(((Player)opponent).getName() + "n/" + "Chips:" + ((Player)opponent).getChips());
        Player roundPlayer1;
        Player roundPlayer2;
        
        
        if(player.getPlayersTurn())
        {
            roundPlayer2 = player;
            roundPlayer1 = (Player)opponent;
        }
        else
        {
            roundPlayer2 = (Player)opponent;
            roundPlayer1 = player;
        }
        roundPlayer1.swapDealer();
        roundPlayer2.swapDealer();
        if (player.dealerCheck()) {
            
            gameInfoText.setText("You are the dealer for this round.");
             
        } else {
            
            appendGameText("Your opponent is the dealer for this round.");    
        }
        
        appendGameText(roundPlayer1.placeBlinds());
        appendGameText(roundPlayer2.placeBlinds());
        updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
        updatePlayerChips(player.getName(),player.getChips());
        player.dealHand(deck);
        ((Player)opponent).dealHand(deck);
        //give PlayerHand here( deal and flip their cards for them.)
        setPlayerPocketCards(player.getHand(), player);
        setOpponentPocketCards(((Player)opponent).getHand(), opponent);
        toggleButtonDisplay(true, false, false, true, false, false);
        appendGameText("Player Hand: " + player.returnHand().toString());
        appendGameText("Opponent Hand: " + opponent.returnHand().toString());
        //this is the bet before the flop;
        currentRound(player, activeOpponent, table, deck, pot, 0);
        updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
        updatePlayerChips(player.getName(),player.getChips());
        //this is the flop(turn three table cards over).
        table.addCardToTable(deck);
        table.addCardToTable(deck);
        table.addCardToTable(deck);
        addTableCardToDisplay(table.getTableCards(), table, 0);
        addTableCardToDisplay(table.getTableCards(), table, 1);
        addTableCardToDisplay(table.getTableCards(), table, 2);
        appendGameText(((Card)table.getTableCards().get(0)).toString());
        appendGameText(((Card)table.getTableCards().get(1)).toString());
        appendGameText(((Card)table.getTableCards().get(2)).toString());
        //first betting round after flop
        currentRound(player, activeOpponent, table, deck, pot, 1);
        updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
        updatePlayerChips(player.getName(),player.getChips());
         //puts fourth card on table i.e. the turn
        currentRound(player, activeOpponent, table, deck, pot, 2);
        table.addCardToTable(deck);
        addTableCardToDisplay(table.getTableCards(), table, 3);
        // next round of betting currentRound2
        currentRound(player, activeOpponent, table, deck, pot, 3);
        //puts fifth and final card on the table, i.e. the river
        table.addCardToTable(deck);
        addTableCardToDisplay(table.getTableCards(), table, 4);
        //final round of betting currentRound 3
        currentRound(player, activeOpponent, table, deck, pot, 4);
     }
    
       
    /**
     *
     * @param hand
     * @param player
     */
    public void setPlayerPocketCards(ArrayList<Card> hand, Player player)
    {
           for ( int cardIndex  =  0 ;
                   cardIndex  <  2 ;
                   cardIndex  ++ ){
            
            player.getHand().get(cardIndex);
            playerCards.getChildren().add(player.getHand().get(cardIndex));
           }
         
         playerVBox.getChildren().clear() ;
         playerVBox.getChildren().add(playerCards);   
     }
    
    /**
     *
     * @param hand
     * @param opponent
     */
    public void setOpponentPocketCards(ArrayList<Card> hand, Opponent opponent)
    {
         
           for ( int cardIndex  =  0; cardIndex  <  2; cardIndex++ ){
             
            opponent.getHand().get(cardIndex);
            opponentCards.getChildren().add(opponent.getHand().get(cardIndex)) ;
           }
            opponentVBox.getChildren().clear() ;
            opponentVBox.getChildren().add(opponentCards);
       
         
     }
    
    /**
     *
     * @param tableCards
     * @param table
     * @param card
     */
    public void  addTableCardToDisplay(ArrayList<Card> tableCards, Table table, int card)
	{
            table.getTableCards().get(card);
            tableCardsArea.getChildren().add(table.getTableCards().get(card)) ;
	}
    
    /**
     *
     * @param newText
     */
    public void appendGameText(String newText) 
    {
        gameInfoText.setText(gameInfoText.getText() + "\n" + newText + "\n");
    }
    
    /**
     *
     * @param update
     */
    public void updatePot(int update)
    {
        potInfo.setText("Pot: " + update);
    }
    
    /**
     *
     * @param name
     * @param update
     */
    public void updateOpponentChips(String name, int update)
    {
        opponentNameChips.setText(name + "\n" + "Chips:" + update);
    }
    
    /**
     *
     * @param name
     * @param update
     */
    public void updatePlayerChips(String name, int update)
    {
        playerNameChips.setText(name + "\n" + "Chips:" + update);
    }
    
    /**
     *
     * @param player
     * @param opponent
     * @param table
     * @param deck
     * @param pot
     * @param stage
     */
    public void currentRound(Player player, Opponent opponent, Table table, Deck deck, Pot pot, int stage)
    {
	if(stage == 0)
	{
		appendGameText("Pre-Flop Betting Round");
                if (player.dealerCheck()) {
                player.playersTurnToTrue();
                } else {
                player.playersTurnToFalse();
                }
		updatePot(pot.getPotAmount());
                updatePlayerChips(player.getName(),player.getChips());
                
                toggleButtonDisplay(false, true, false, true, true, false);
                   
                opponent.makeChoice(stage, 1);
                
                updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
                updatePlayerChips(player.getName(),player.getChips());
	}
	
	if(stage == 1)
	{
		appendGameText("Flop Betting Round");
		updatePot(pot.getPotAmount());
                updatePlayerChips(player.getName(),player.getChips());
                toggleButtonDisplay(true, false, false, true, false, false);
                opponent.makeChoice(stage, 1); 
                updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
                updatePlayerChips(player.getName(),player.getChips());
	}
	
	if(stage == 2)
	{
		appendGameText("Turn Betting Round");
		updatePot(pot.getPotAmount());
                updatePlayerChips(player.getName(),player.getChips());
		toggleButtonDisplay(true, false, false, true, false, false);
		opponent.makeChoice(stage, 1);
                updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
                updatePlayerChips(player.getName(),player.getChips());
	}
	
	if(stage == 3)
	{
		appendGameText("River Betting Round");
		updatePot(pot.getPotAmount());
                updatePlayerChips(player.getName(),player.getChips());
		toggleButtonDisplay(true, false, false, true, false, false);
		opponent.makeChoice(stage, 1);
                updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
                updatePlayerChips(player.getName(),player.getChips());
	}
	
	if(stage == 4)
	{
		appendGameText("Showdown");
    
		HandEvaluator handEval = new HandEvaluator();
    
		ArrayList<Card> player1AllCards = handEval.concatenateCardsToArrayList(player.returnHand(), table);
		ArrayList<Card> player2AllCards = handEval.concatenateCardsToArrayList(opponent.returnHand(), table);
    
		appendGameText("Player1 All cards");
		appendGameText(player1AllCards.toString());
    
		appendGameText("Player2 All cards");
		appendGameText(player2AllCards.toString());
    
		PokerHands player1Hand = handEval.evaluate(player1AllCards);
		PokerHands player2Hand = handEval.evaluate(player2AllCards);
    
		appendGameText("Player1Hand");
		appendGameText(player1Hand.toString());
		appendGameText("Player2Hand");
		appendGameText(player2Hand.toString());
		if (handEval.compareHands(player1Hand, player1AllCards, player2Hand, player2AllCards) == 1)
		{
			appendGameText(player.getName() + " won the hand with " + player1Hand.toString());
			appendGameText(player.getName() + " won " + pot.getPotAmount() + " chips!");
			pot.wonPot(player);
                        updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
                        updatePlayerChips(player.getName(),player.getChips());
			toggleButtonDisplay(false, true, true, true, true, true);
                        
		}
		else if (handEval.compareHands(player1Hand, player1AllCards, player2Hand, player2AllCards) == 2)
		{
			appendGameText(opponent.getName() + " won the hand with " + player2Hand.toString());
			appendGameText(opponent.getName() + " won " + pot.getPotAmount() + " chips!");
			pot.wonPot((Player)opponent);
                        updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
                        updatePlayerChips(player.getName(),player.getChips());
			toggleButtonDisplay(false, true, true, true, true, true);
                        
		}
		else if (handEval.compareHands(player1Hand, player1AllCards, player2Hand, player2AllCards) == 0)
		{
			appendGameText("You both had a " + player1Hand.getName() + "!");
			appendGameText("You both share the pot of " + pot.getPotAmount() + " chips!");
			pot.sharePot(player, (Player)opponent);
                        updateOpponentChips(((Player)opponent).getName(),((Player)opponent).getChips());
                        updatePlayerChips(player.getName(),player.getChips());
			toggleButtonDisplay(false, true, true, true, true, true);
		}
                appendGameText("Game has finished.");
	}
    }
    
    /**
     *
     * @param player
     * @param opponent
     * @param pot
     * @param table
     */
    public void endHand(Player player, Opponent opponent, Pot pot, Table table)
    {
        player.clearHand();
        opponent.clearHand();
        table.clearTableCards();
        Deck nextDeck = new Deck();
        playGame(player, activeOpponent, table, nextDeck, pot);
    }
    
}
