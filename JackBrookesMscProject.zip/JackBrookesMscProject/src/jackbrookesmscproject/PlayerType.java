
package jackbrookesmscproject;

/**
 *
 * @author Jzb3
 */
public enum PlayerType
{
  TIGHTAGGRESSIVE,  LOOSEAGGRESSIVE,  TIGHTPASSIVE,  LOOSEPASSIVE;
}
