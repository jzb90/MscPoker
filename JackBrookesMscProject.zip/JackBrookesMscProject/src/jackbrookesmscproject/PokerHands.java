/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class PokerHands
{
  protected int value;
  protected ArrayList<Card> cards;
  protected String name;
  protected Card kicker;
  
  public PokerHands(ArrayList<Card> cards)
  {
    this.cards = cards;
  }
  
  public String toString()
  {
    try
    {
      String cardString = getName() + ": ";
      for (Card x : this.cards) {
        cardString = cardString + x.toString() + ", ";
      }
      if (this.kicker != null) {}
      return cardString + "With " + this.kicker.toString() + "kicker.";
    }
    catch (NullPointerException e)
    {
      System.out.println("toString NPE thrown...");
    }
    return null;
  }
  
  public int getValue()
  {
    return this.value;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  
  /**
     * @return ArrayList
     */
  public ArrayList<Card> getArrayList()
  {
    return this.cards;
  }
  
  
  /**
     * @return Card
     */
  public Card getKicker()
  {
    return this.kicker;
  }
  
  
  /**
     * @param card
     */
  public void setKicker(Card card)
  {
    this.kicker = card;
  }
  
  public static class Highcard
    extends PokerHands
  {
    public Highcard(ArrayList<Card> cards)
    {
      super(cards);
      this.name = "Highcard";
      this.value = 1;
    }
  }
  
  public static class OnePair
    extends PokerHands
  {
    public OnePair(ArrayList<Card> cards)
    {
      super(cards);
      this.name = "One pair";
      this.value = 2;
    }
  }
  
  public static class TwoPair
    extends PokerHands
  {
    public TwoPair(ArrayList<Card> cards)
    {
      super(cards);
      this.name = "Two pair";
      this.value = 3;
    }
  }
  
  public static class ThreeOfAKind
    extends PokerHands
  {
    public ThreeOfAKind(ArrayList<Card> cards)
    {
      super(cards);
      this.name = "Three of a kind";
      this.value = 4;
    }
  }
  
  public static class Straight
    extends PokerHands
  {
    public Straight(ArrayList<Card> cards)
    {
      super(cards);
      this.name = "Straight";
      this.value = 5;
    }
  }
  
  public static class Flush
    extends PokerHands
  {
    public Flush(ArrayList<Card> cards)
    {
      super(cards);
      this.name = "Flush";
      this.value = 6;
    }
  }
  
  public static class FullHouse
    extends PokerHands
  {
    public FullHouse(ArrayList<Card> cards)
    {
      super(cards);
      this.name = "Fullhouse";
      this.value = 7;
    }
  }
  
  public static class FourOfAKind
    extends PokerHands
  {
    public FourOfAKind(ArrayList<Card> cards)
    {
      super(cards);
      this.name = "Four of a kind";
      this.value = 8;
    }
  }
  
  public static class StraightFlush
    extends PokerHands
  {
    public StraightFlush(ArrayList<Card> cards)
    {
      super(cards);
      this.name = "Straight flush";
      this.value = 9;
    }
  }
}
