/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

import java.util.ArrayList;
/**
 *
 * @author Admin
 */
public class Table
{
  private ArrayList<Card> tableCards;
  
  public Table()
  {
    this.tableCards = new ArrayList();
  }
  
  public Table(Card card1, Card card2, Card card3, Card card4, Card card5)
  {
    this.tableCards = new ArrayList();
    this.tableCards.add(card1);
    this.tableCards.add(card2);
    this.tableCards.add(card3);
    this.tableCards.add(card4);
    this.tableCards.add(card5);
  }
  
  public Table(Card card1, Card card2, Card card3)
  {
    this.tableCards = new ArrayList();
    this.tableCards.add(card1);
    this.tableCards.add(card2);
    this.tableCards.add(card3);
  }
  
  /**
     * @param deck
     */
  public void addCardToTable(Deck deck)
  {
    this.tableCards.add(deck.drawRandomCard());
  }
  
  /**
     * @return ArrayList
     */
  public ArrayList<Card> getTableCards()
  {
    return this.tableCards;
  }
  
  public void clearTableCards()
  {
    this.tableCards.clear();
  }
  
  public String toString()
  {
    String tableString = "Table cards: ";
    for (Card c : this.tableCards)
    {
      tableString = tableString + c.toString();
      tableString = tableString + " ";
    }
    tableString = tableString + ".";
    return tableString;
  }
}
