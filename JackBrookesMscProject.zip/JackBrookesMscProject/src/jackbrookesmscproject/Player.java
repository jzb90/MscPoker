/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */

public class Player
{
  public String name;
  private int chips;
  protected boolean dealer;
  private Hand playerHand;
  private Opponent botOpponent;
  private Player playerOpponent;
  public Player player;
  private Pot pot;
  private PlayStyle playStyle;
  private PlayStyle opponentPlaystyle;
  private boolean playersTurn = true;
  private int amountBet = 0;
  private int amountWon = 0;
  private int roundsPlayed = 0;
  private int betTag;
  
  public Player(String name, boolean isDealer, Pot pot, Boolean turn)
  {
    setName(name);
    this.chips = 1000;
    this.dealer = isDealer;
    this.pot = pot;
    this.playersTurn = turn.booleanValue();
    betTag = 0;
    
  }
  
  public Player getPlayer(){
      
      return this.player;
  }
  
  public Pot getPot()
  {
      return this.pot;
  }
  
  public void setOpponentPlayStyle(PlayStyle x)
  {
    this.opponentPlaystyle = x;
  }
  
  public PlayStyle getOpponentPlayStyle()
  {
    return this.opponentPlaystyle;
  }
  
  public boolean getPlayersTurn()
  {
    return this.playersTurn;
  }
  
  public void setPlayersTurn()
  {
    if (this.playersTurn) {
      this.playersTurn = false;
    } else {
      this.playersTurn = true;
    }
  }
  
  public void playersTurnToTrue()
  {
    this.playersTurn = true;
  }
  
  public void playersTurnToFalse()
  {
    this.playersTurn = false;
  }
  
  public int getRoundsPlayed()
  {
    return this.roundsPlayed;
  }
  
  public void setRoundsPlayed(int roundsPlayed)
  {
    this.roundsPlayed = roundsPlayed;
  }
  
  
  public int getAmountBet()
  {
    return this.amountBet;
  }
  
  public void setAmountBet(int amountBet)
  {
    this.amountBet = amountBet;
  }
  
  public void setBetTag(int betTag)
  {
      this.betTag = betTag;
  }
  
  public int getBetTag()
  {
      return betTag;
  }
  
  public int getAmountWon()
  {
    return this.amountWon;
  }
  
  public void setAmountWon(int amountWon)
  {
    this.amountWon = amountWon;
  }
  
  public Player(String name)
  {
    setName(name);
    this.chips = 1000;
  }
  
  public void incrementAmountWon(int amount)
  {
    this.amountWon += amount;
  }
  
  
  public void setOpponent(Player player)
  {
    if ((player instanceof Opponent)) {
      this.botOpponent = ((Opponent)player);
    } else {
      this.playerOpponent = player;
    }
  }
  
  public void setBotOpponent(Opponent x)
  {
    this.botOpponent = x;
  }
  
  public Opponent getOpponent()
  {
    return this.botOpponent;
  }
  
  public Player getPlayerOpponent()
  {
      return this.playerOpponent;
  }
  
  protected int getChips()
  {
    return this.chips;
  }
  
  protected void setChips(int chips)
  {
    this.chips = chips;
  }
  
  public void addChips(int amount)
  {
    this.chips += amount;
  }
  
  public void setPot(Pot pot)
  {
    this.pot = pot;
  }
  
  public boolean dealerCheck()
  {
    return this.dealer;
  }
  
  public void setDealer()
  {
    this.dealer = true;
  }
  
  public void setNotDealer()
  {
    this.dealer = false;
  }
  
  public void swapDealer()
  {
    if (this.dealer) {
      this.dealer = false;
    } else {
      this.dealer = true;
    }
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    this.name = name;
  }
  
  public void dealHand(Deck deck)
  {
    this.playerHand = new Hand(deck);
    this.roundsPlayed += 1;
  }
  
  public void clearHand()
  {
    this.playerHand.clearHand();
  }
  
  public ArrayList<Card> getHand()
  {
    return this.playerHand.getDealtCards();
  }
  
  public Hand returnHand()
  {
    return this.playerHand;
  }
  
  public String placeBlinds()
  {
    if (dealerCheck()) {
      return smallBlind();
    }
    return bigBlind();
  }
  
  public String smallBlind()
  {
    if (this.chips >= 10)
    {
      this.chips -= 10;
      this.pot.addToPot(10);
    }
    return this.name + " placed the small blind of 10, leaving them with " + this.chips + " chips.";
  }
  
  public String bigBlind()
  {
    if (this.chips >= 20)
    {
      this.chips -= 20;
      this.pot.addToPot(20);
      this.amountBet += 20;
    }
    return this.name + " placed the big blind of 20, leaving them with " + this.chips + " chips.";
  }
  
  public String smallBet(boolean reRaise, int betTag)
  {
    if (reRaise)
    {
      this.chips -= 40;
      this.pot.addToPot(40);
      this.betTag += 40;
      return this.name + " re-raised the small bet of 20, leaving them with " + this.chips + " chips.";
    }
    if (this.chips >= 20)
    {
      this.chips -= 20;
      this.pot.addToPot(20);
      this.amountBet += 20;
    }
    return this.name + " placed a small bet of 20, leaving them with " + this.chips + " chips.";
  }
  
  public String largeBet(boolean reRaise, int betTag)
  {
    if (reRaise)
    {
        //changed amountBet to betTag
      this.chips -= 80;
      this.pot.addToPot(80);
      this.betTag += 80;
      return this.name + " re-raised the big bet of 40, leaving them with " + this.chips + " chips.";
    }
    this.chips -= 40;
    this.pot.addToPot(40);
    this.amountBet += 40;
    return this.name + " placed a big bet of 40, leaving them with " + this.chips + " chips.";
  }
  
  public PlayStyle getPlayStyle()
  {
    return this.playStyle;
  }
  
  public void fold(Player player, Player player2, Pot pot){
        //player2 was opponent
        //put game info update in the actual handlebutton method

        System.out.println(player.getName() + " folded.");
        player.setPlayersTurn();
        System.out.println(player2.getName()+ " won " + pot.getPotAmount() + " chips!");
        pot.wonPot(player2);
        //waitForAClickToStartNewGame was here.
    }
    
    public void raise(Player player, Pot pot, int bet){
              
        player.setPlayersTurn();
        setBetTag(bet);
        this.chips = player.getChips() - bet;
        pot.addToPot(player.getAmountBet()); 
        System.out.println(this.name + " placed a bet of " + bet + ", leaving them with " + this.chips + " chips.");
    }
    
    public void check(Player player, Pot pot){
        
	player.setPlayersTurn();
	pot.addToPot(0);
	System.out.println(player.getName() + " checked.");
    }
    
    public void call(Player player, Player player2)
      
    {
              
        player.setAmountBet(getBetTag());
        this.chips = player.getChips() - getBetTag();
        pot.addToPot(getBetTag());
        System.out.println(this.name + " matched the bet of " + getBetTag() + " leaving them with " + this.chips + " chips.");
        
    }
}
