/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jackbrookesmscproject;

import java.util.ArrayList;
import java.util.Collections;
/**
 *
 * @author Admin
 */



public class Hand
{
  private ArrayList<Card> dealtCards;
  
  public Hand(Deck deck)
  {
    this.dealtCards = new ArrayList();
    for (int i = 0; i < 2; i++) {
      this.dealtCards.add(deck.drawRandomCard());
    }
    orderHand(this);
  }
  
  public Hand(Card card1, Card card2)
  {
    this.dealtCards = new ArrayList();
    this.dealtCards.add(card1);
    this.dealtCards.add(card2);
    orderHand(this);
  }
  
  public ArrayList<Card> getDealtCards()
  {
    return this.dealtCards;
  }
  
  public void clearHand()
  {
    this.dealtCards.clear();
  }
  
  public void orderHand(Hand hand)
  {
    if (((Card)this.dealtCards.get(0)).getGrade() > ((Card)this.dealtCards.get(1)).getGrade()) {
      swapArrayCards(this.dealtCards, 0, 1);
    }
  }
  
  public static ArrayList<Card> orderArrayList(ArrayList<Card> cards)
  {
    orderBySuit(cards);
    orderByGrade(cards);
    return cards;
  }
  
  public static ArrayList<Card> orderBySuit(ArrayList<Card> cards)
  {
    ArrayList<Card> temp = new ArrayList();
    temp.addAll(cards);
    cards.clear();
    for (int suit = 3; suit >= 0; suit--) {
      for (Card x : temp) {
        if (x.getSuit() == suit) {
          cards.add(0, x);
        }
      }
    }
    return cards;
  }
  
  public static ArrayList<Card> orderByGrade(ArrayList<Card> cards)
  {
    Collections.sort(cards, new CustomComparator());
    return cards;
  }
  
  public static void orderByGradeAcesLast(ArrayList<Card> cards)
  {
    Collections.sort(cards, new CustomComparator());
    for (int i = cards.size() - 1; i >= 0; i--) {
      if (((Card)cards.get(i)).getGrade() == 0)
      {
        Card temp = (Card)cards.remove(i);
        cards.add(cards.size(), temp);
      }
    }
  }
  
  public static Card containsGrade(ArrayList<Card> cards, int grade)
  {
    for (Card x : cards) {
      if (x.getGrade() == grade) {
        return x;
      }
    }
    return null;
  }
  
  public static void swapArrayCards(ArrayList<Card> ArrayList, int x, int y)
  {
    Card temporary = (Card)ArrayList.get(x);
    ArrayList.set(x, (Card)ArrayList.get(y));
    ArrayList.set(y, temporary);
  }
  
  @Override
  public String toString()
  {
    return ((Card)this.dealtCards.get(0)).toString() + " and " + ((Card)this.dealtCards.get(1)).toString();
  }
}
